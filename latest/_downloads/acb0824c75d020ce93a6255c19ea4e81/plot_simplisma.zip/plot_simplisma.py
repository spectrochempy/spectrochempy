# %%
# ======================================================================================
# Copyright (©) 2014-2026 Laboratoire Catalyse et Spectrochimie (LCS), Caen, France.
# CeCILL-B FREE SOFTWARE LICENSE AGREEMENT
# See full LICENSE agreement in the root directory.
# ======================================================================================
# ruff: noqa
"""
SIMPLISMA example
=================
In this example, we perform the PCA dimensionality reduction of a spectra
dataset

"""

# %%
# Import the package
import spectrochempy as scp

# %%
# Load and annotate the dataset
# ------------------------------
print("Dataset (Jaumot et al., Chemometr. Intell. Lab. 76 (2005) 101-110)):")
lnd = scp.read_matlab("matlabdata/als2004dataset.MAT", merge=False)
for mat in lnd:
    print("    " + mat.name, str(mat.shape))

ds = lnd[-1]
_ = ds.plot()

# %%
# Add metadata for a nicer display. The archived file does not store the
# physical elution time and wavelength coordinates, so the axes are plain
# indices without physical units:
ds.title = "absorbance"
ds.units = "absorbance"
ds.set_coordset(None, None)
ds.y.title = "elution time (index)"
ds.x.title = "wavelength (index)"

# %%
# Fit the SIMPLISMA model
# ------------------------
print("Fit SIMPLISMA on {}\n".format(ds.name))
simpl = scp.SIMPLISMA(n_components=20, tol=0.2, noise=3, log_level="INFO")
_ = simpl.fit(ds)

# %%
# Visualize the results
# ----------------------
# Concentration profiles:
_ = simpl.C.T.plot(title="Concentration")

# %%
# Pure component spectra:
_ = simpl.components.plot(title="Pure profiles")

# %%
# Merit plot after reconstruction:
_ = simpl.plot_merit(offset=0, nb_traces=5)

# %%
# Uncomment the following line to display all figures when running the script
# directly with Python.

# %%

# scp.show()
