# %%
# ======================================================================================
# Copyright (©) 2014-2026 Laboratoire Catalyse et Spectrochimie (LCS), Caen, France.
# CeCILL-B FREE SOFTWARE LICENSE AGREEMENT
# See full LICENSE agreement in the root directory.
# ======================================================================================
# ruff: noqa
"""
Sine bell and squared Sine bell window multiplication
=====================================================

In this example, we use sine bell or squared sine bell window multiplication to apodize a NMR signal in the time domain.

Requires the official ``spectrochempy-nmr`` plugin.
Install with: ``pip install spectrochempy[nmr]``.

"""
# sphinx_gallery_thumbnail_path = 'gettingstarted/examples/gallery/auto_examples_processing/apodization/images/thumb/sphx_glr_plot_proc_sp_thumb.png'

# %%
import spectrochempy as scp

DATADIR = scp.preferences.datadir
path = DATADIR / "nmrdata" / "bruker" / "tests" / "nmr" / "topspin_1d"

# %%
dataset1D = scp.nmr.read(path, expno=1, remove_digital_filter=True)
dataset1D

# %%
# Normalize the dataset values and reduce the time domain
dataset1D /= dataset1D.real.data.max()  # normalize
dataset1D = dataset1D[0.0:15000.0]

# %%
# Apply Sine bell window apodization with parameter ssb=2, which correspond to a cosine function
new1, curve1 = scp.sinm(dataset1D, ssb=2, retapod=True, inplace=False)

# %%
# this is equivalent to
new1, curve1 = dataset1D.sinm(ssb=2, retapod=True, inplace=False)

# %%
# or also
new1, curve1 = scp.sp(dataset1D, ssb=2, pow=1, retapod=True, inplace=False)

# %%
# Apply Sine bell window apodization with parameter ssb=2, which correspond to a sine function
new2, curve2 = dataset1D.sinm(ssb=1, retapod=True, inplace=False)

# %%
# Apply Squared Sine bell window apodization with parameter ssb=1 and ssb=2
new3, curve3 = scp.qsin(dataset1D, ssb=2, retapod=True, inplace=False)
new4, curve4 = dataset1D.qsin(ssb=1, retapod=True, inplace=False)

# %%
# Apply shifted Sine bell window apodization with parameter ssb=8 (mixed sine/cosine window)
new5, curve5 = dataset1D.sinm(ssb=8, retapod=True, inplace=False)

# %%
# Plotting
_ = dataset1D.plot(zlim=(-2, 2), color="k")
_ = curve1.plot(color="r", clear=False)
_ = new1.plot(
    data_only=True, color="r", clear=False, label=" sinm with ssb= 2 (cosine window)"
)
_ = curve2.plot(color="b", clear=False)
_ = new2.plot(
    data_only=True, color="b", clear=False, label=" sinm with ssb= 1 (sine window)"
)
_ = curve3.plot(color="m", clear=False)
_ = new3.plot(data_only=True, color="m", clear=False, label=" qsin with ssb= 2")
_ = curve4.plot(color="g", clear=False)
_ = new4.plot(data_only=True, color="g", clear=False, label=" qsin with ssb= 1")
_ = curve5.plot(color="c", ls="--", clear=False)
_ = new5.plot(
    data_only=True,
    color="c",
    ls="--",
    clear=False,
    label=" sinm with ssb= 8",
    legend="best",
)

# %%
# This ends the example ! The following line can be uncommented if no plot shows when
# running the .py script with python
# scp.show()
# sphinx_gallery_thumbnail_number = -1
